<html>
<head>
<title>Template 18</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

</head>

<body bgcolor="#FFFFFF" text="#000000" link="#003399" vlink="#6699FF" alink="#003399">
<table width="750" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="154">
      <table width="154" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><img src="images/logo_top.gif" width="154" height="48"></td>
        </tr>
        <tr>
          <td><p align="center"> <font color="#00CC66" size="5" face="Times New Roman, Times, serif"><strong>Meisam Hejazinia</strong></font></p></td>
        </tr>
        <tr>
          <td><img src="images/logo_bottom.gif" width="154" height="45"></td>
        </tr>
      </table>
    </td>
    <td height="137" width="596">
      <table width="596" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td height="48">&nbsp;</td>
        </tr>
        <tr>
          <td height="44"><img src="images/neon_top_nav.gif" width="596" height="19"><br><a href="index.php
			">
            <img src="images/HW1_on.gif" width="96" height="24"></a><a href="index2.php
			"><img src="images/HW2.gif" width="96" height="24" border="0"></a><a href="index3.php
			"><img src="images/link3_off.gif" width="96" height="24" border="0"></a><a href="index4.htm"><img src="images/link4_off.gif" width="96" height="24" border="0"></a><a href="index5.php"><img src="images/link5_off.gif" width="96" height="24" border="0"></a><a href="index6.php"><img src="images/link6_off.gif" width="96" height="24" border="0"></a>          </td>
        </tr>
        <tr>
          <td height="45">
            <table width="596" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="65%" align="right"><b><font face="Verdana, Arial, Helvetica, sans-serif" color="#003399">Welcome 
                  to Meisam hejazinia website</font></b></td>
                <td>&nbsp;</td>
              </tr>
            </table>          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="750" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="50%"> 
      <p>&nbsp;</p>
     
<!-- PAGE HEADER Start -->
<FORM class="nospace" method="get" action="/cgi/search.pl" name="searchform">

<!--  <DIV id="pageHeader"> -->
<table width="100%" cellpadding="0" cellspacing="0" border="0">

<tr><!-- Row B - Divider -->
<td colspan="7" bgcolor="#000066"><img src="/images/common/empty.gif" width="1" height="1"/></td>
</tr>

<tr><!-- Row B - Divider -->
<td bgcolor="#000066" rowspan="9"><img src="/images/common/empty.gif" width="1" height="1"/></td>
<td bgcolor="#DDDDDD" colspan="5"><img src="/images/common/empty.gif" width="1" height="1"/></td>
<td bgcolor="#000066" rowspan="9"><img src="/images/common/empty.gif" width="1" height="1"/></td>
</tr>

<tr><!-- Row A - BCCRC -->
<td width="10" bgcolor="#DDDDDD"><img src="/images/common/empty.gif" width="10" height="1"/></td>
<td bgcolor="#66CC66"><font color="#FFFF33" size="2" face="Verdana, Arial, Helvetica, sans-serif"><A class="homelink" href="/index.html" title="Meisam hejazynia Homepage"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Welcome to Meisam Hejazynia's Home page 
      <script type="text/javascript"> showcookie()</script> 
</A></font></td>
<td width="10" bgcolor="#66CC66"><font color="#FFFF33"><img src="/images/common/empty.gif" width="10" height="1"/></font></td>
<td bgcolor="#66CC66" align="right"><font color="#FFFF33" size="1" face="Verdana, Arial, Helvetica, sans-serif"><INPUT id="searchInput" size="25" name="find" value="">&nbsp;<input id="searchButton" type="submit" value="Search"/></font></td>
<td width="10"  bgcolor="#DDDDDD"><img src="/images/common/empty.gif" width="10" height="1"/></td>
</tr>

<tr><!-- Row B - Divider -->
<td colspan="5" bgcolor="#000066"><img src="/images/common/empty.gif" width="1" height="1"/></td>
</tr>

<tr><td colspan="5">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#DDDDDD">
      </table>    </td>
  </tr>
</table>
</td></tr>


<tr><!-- Row F - Divider -->
<td colspan="5" bgcolor="#000066"><img src="/images/common/empty.gif" width="1" height="1"></td>
</tr>
<tr><!-- Row F - Divider -->
<td colspan="5" bgcolor="#DDDDDD"><img src="/images/common/empty.gif" width="1" height="1"></td>
</tr>

<tr><!-- Row G - You are Here -->
<td colspan="5" bgcolor="#66CC99"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font>
<DIV id="youarehere"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><B>Meisam Hejazinia </B></font></DIV></td>
</tr>

<tr><!-- Row F - Divider -->
<td colspan="5" bgcolor="#DDDDDD"><img src="/images/common/empty.gif" width="1" height="1"></td>
</tr>
<tr><!-- Row H - Divider -->
<td colspan="5" bgcolor="#000066"><img src="/images/common/empty.gif" width="1" height="2"></td>
</tr>
</table>
</FORM>

<!-- PAGE HEADER End -->

<!--  <DIV class="clearall"/> -->

<!-- START MAIN BODY TABLE -->

<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr valign="top">

<td><table width="100%" cellpadding="0" cellspacing="0" border="0">




<tr><td bgcolor="#487FBA"><table align="right" cellpadding="0" cellspacing="0" border="0"><tr><td align="right" bgcolor="#FFFFFF" class="deptccr"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;Computer and IT Research&nbsp;</font></td></tr></table></td></tr>


<tr><td bgcolor="#000000">
<table width="100%" cellpadding="10" cellspacing="1" border="0"><tr><td bgcolor="#FFFFFF">
<font size="2" face="Verdana, Arial, Helvetica, sans-serif">
<!--  Personal -->
  <!-- Page Title START -->
  <p>Hello. Today is: <script LANGUAGE="JAVASCRIPT">
<!--//
document.write(todaysDate)
//-->
</script> </p>
</font>
<form NAME="formTime" METHOD="POST" ENCTYPE="TEXT/PLAIN">
  <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
    <input TYPE="TEXT" NAME="textTime" SIZE="25" MAXLENGTH="25"> 
    <br>
    </font>
  <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"></font>
    <font size="2" face="Verdana, Arial, Helvetica, sans-serif">      </font></font></p>
</form>
<font size="2" face="Verdana, Arial, Helvetica, sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" border="0">
  <tr><td><img src="/images/common/empty.gif" width="300" height="1"></td></tr>
  <tr><td width="100%" bgcolor="#990000"><img src="/images/common/empty.gif" width="300" height="1"></td></tr>
  <tr><td><img src="/images/common/empty.gif" width="300" height="1"></td></tr>
  <tr><td width="100%" bgcolor="#990000"><img src="/images/common/empty.gif" width="300" height="1"></td></tr>
  <tr><td><img src="/images/common/empty.gif" width="300" height="1"></td></tr>
</table>
<!-- Page Title END -->
  <!-- Content START -->
                                       <!-- Bio Template START -->
                  <table align="right" width="1%" border="0" cellpadding="0" cellspacing="0">
  <tr><td bgcolor="#000000">
  <table width="100%" border="0" cellpadding="3" cellspacing="1"> 
  <tr><td bgcolor="#FFFFFF"><font size="2">
    <IMG src="index/DSC022311.jpg" width="210" height="158"><br/>
    
  </font></td></tr></table>
  </td></tr>
                  </table>
</font>
<DIV id="bioInternet"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><A href="mailto:meisam.hejazynia@gmail.com" class="email" title="Send email to meisam.hejazynia@gmail.com"><IMG src="/images/common/mailto.gif" BORDER="0" width="14" height="10" alt="Send email to meisam.hejazynia@gmail.com">&nbsp;meisam.hejazinynia@gmail.com</A><BR>
</font></DIV>
<font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font><DIV id="bioTitle"><UL><LI><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Diploma from Highschool of Allame Helli in 2001,Boronz medal in Internal Mathematic Olympiad ,2001</font></LI><LI><font size="2" face="Verdana, Arial, Helvetica, sans-serif">First year of University in Ferdowsi University of Mashhad, 2003</font></LI>
  <LI><font size="2">BS degree in Information technology 2007 </font></LI>
  <LI><font size="2">dominant in IAUMCCC personal programming contest April 2004 </font></LI>
  <li><font size="2" face="Verdana, Arial, Helvetica, sans-serif">BS degree in Computer Engineering 2007</font></li>
  <li><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Work in Sabalan Parcheh as an IT Expert 2005 </font></li>
</UL>
</DIV>


<font size="2" face="Verdana, Arial, Helvetica, sans-serif"><P><A class="navi" href="pubs_mrosin.html"></A></P>


<TABLE border="0" cellpadding="3" cellspacing="0">
  
    <TR valign="top">
      <TD class="bioKey"><SPAN class="bioKey">Department:</SPAN></TD>
      <TD class="bioVal"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Computer &amp; IT Faculty </font></TD>
    </TR>
  
  
    <TR valign="top">
      <TD class="bioKey"><SPAN class="bioKey"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Accupation</font></SPAN></TD>
      <TD class="bioVal"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">BS Student </font></TD>
    </TR>
  
  
  
  
  
  
  
  
  
    <TR valign="top">
      <TD class="bioKey"><SPAN class="bioKey">Education:</SPAN></TD>
      <TD class="bioVal">B.Sc.<font size="2" face="Verdana, Arial, Helvetica, sans-serif">in Amirkabir University of tehran </font><BR></TD>
    </TR>
  
  
  
    <TR valign="top">
      <TD class="bioKey"><SPAN class="bioKey">Phone:</SPAN></TD>
      <TD class="bioVal"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">+98-9121247676</font></TD>
    </TR>
  
  
    <TR valign="top">
      <TD class="bioKey"><SPAN class="bioKey">Fax:</SPAN></TD>
      <TD class="bioVal"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">+98-9121247676</font></TD>
    </TR>
  
  <TR><TD></TD></TR>
</TABLE>

<P class="subhead">Research Interests:</P>
<DIV id="bioResearchTopic"><LI>Enterprise Resourse Planning(ERP) Implementation and Rapid Implementation</LI><LI>Customer Relationship Management(CRM) specially Datamining</LI><LI>Business Process Reengineering</LI><LI>Artificial Intelligence and Expert Systems</LI></DIV>
  </font>
<P><font size="2">Project that I had in my courses  </font><font size="2" face="Verdana, Arial, Helvetica, sans-serif">: </font>
  <font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font><UL>
    <LI><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Search engin for Documents with Vector model with java </font></LI>
    <LI><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Analysing and Designing human Resourse Management System for Special company</font></LI>
    <LI><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Analysing and designing and Implementing a small e-store with CRM System</font></LI>
    <LI><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Writing an Http Server multi thread with java
</font></LI>
  </UL>

  <div align="center"><embed src="chess.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="450" height="400"></embed><br clear="all"/>
  </div>
  <div align="center"></div>
  <table><tr>
      <td><p align="center">
        </p>
      </div></td>
    </tr></table>
  <table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr>
      <td colspan="2" bgcolor="#990000"><img src="/images/common/empty.gif" height="1"></td>
    </tr>
    <tr>
      <td colspan="2" bgcolor="#FFFFFF"><img src="/images/common/empty.gif" height="2"></td>
    </tr>
    <tr>
      <td align="left"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> <a href="#_top_">Top of Page <img src="index/arrow_up.gif" width="8" height="12" border="0"></a> </font></td>
      <td align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> <a href="http://ce.aut.ac.ir" title="Meisam Hejazinia"><img src="index/arrow_left2.gif" width="17" height="13" border="0"> Prev</a> (50 of 69) <a href="http://ce.aut.ac.ir" title="Nelson Ha">Next <img src="file:///C|/Documents and Settings/Eng/Desktop/index/arrow_right2.gif" width="17" height="13" border="0"></a> </font></td>
    </tr>
    <tr>
      <td><p align="left">
        <script type="text/javascript">VisitCounter()</script>
        </p>
          <p align="left">
            <input type="button" value="Change Name" name="B1"
onClick="changename()" >
          </p>
        <p align="left">Theme: </p>
        <dl>
          <dd>
            <input type="RADIO" name="theme"
value="red" onClick="red()">
            Red
          <dd>
            <input type="RADIO" name="theme"
value="green" onClick="green()">
            Green
          <dd>
            <input type="radio" name="theme"
value="blue" onClick="blue()">
            Blue
          </dl>
        <p></p></td>
      <td><?php
function showLoginForm(){
	//	  <input type="hidden" name="action" value="login"/>
print <<<_HTML_
<form method="post" action="index3.php">
		  <table>
		    <tr>
		      <td>Username:</td>
		      <td><input type="text" name="enteredusername" value="" size="15" maxlength="10"/></td>
		    </tr>	
		    <tr>
		      <td>Password:</td>
		      <td><input type="password" name="password" value="" size="15" maxlength="10"/></td>
		    </tr>
		    
		    <tr>
		    <td></td>
		      <td>
		      	<input type="submit" name="submit" value="Login" />	      
		      </td>
		    </tr>    
		  </table>
</form>
		  	
_HTML_;
}
showLoginForm();

//pageFooter();

?></td>
    </tr>
  </table>
  <p align="center"><font size="1">URL: <a href="http://ce.aut.ac.ir">http://ce.aut.ac.ir</a><br/>
      <br/>
  This page was last modified at <font face="Verdana">8</font>:<font face="Verdana">50</font>am on <font face="Verdana">November 03 </font>, 200<font face="Verdana">6</font><br/>
  </font></p>
<!-- End of Footer --></td></tr></table></td></tr>


</table></td>

<td>&nbsp;</td> <!--  Middle Margin -->

<td width="150"><table width="150" cellpadding="0" cellspacing="0" border="0">

<tr><td bgcolor="#000000">
<table width="100%" border="0" cellpadding="2" cellspacing="1" bgcolor="#333333">
<tr><td bgcolor="#6666FF" width="100%" align="center">
<font size="2" face="Verdana, Arial, Helvetica, sans-serif">

<!--
<A class="navi" href="people_mmorris.html" title="Michelle Morris"><B>Prev</B></A> (50 of 69) <A class="navi" href="people_nha.html" title="Nelson Ha"><B>Next</B></A>
-->


<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
<tr><td width="100%" bgcolor="#990000"><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
<tr><td><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
</table>
<b>Navigation Menu</b>
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
<tr><td width="100%" bgcolor="#990000"><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
<tr><td><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
</table>

<TABLE cellpadding="0" cellspacing="0" border="0" bgcolor="#0066CC">
  <TR valign="top" align="left"><TD width="10"><IMG src="/images/common/sb_downarrow.gif" border="0" align="top" vspace="0" alt="" width="9"  height="12"/></TD>
<TD bordercolor="#330099" class="sidebarLink"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">photo<A class="navi" href="../index.html"></A></font></TD>
</TR>
<TR valign="top" align="left"><TD width="10"><IMG src="/images/common/sb_downarrow.gif" border="0" align="top" vspace="0" alt="" width="9"  height="12"/></TD>
<TD bordercolor="#330099" class="sidebarLink"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">company<A class="navi" href="../dept.html"></A></font></TD>
</TR>
<TR valign="top" align="left"><TD width="10"><IMG src="/images/common/sb_downarrow.gif" border="0" align="top" vspace="0" alt="" width="9"  height="12"/></TD>
<TD bordercolor="#330099" class="sidebarLink"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">myfamily<A class="navi" href="index.html"></A></font></TD>
</TR>
<TR valign="top" align="left"><TD width="10"><IMG src="/images/common/sb_downarrow.gif" border="0" align="top" vspace="0" alt="" width="9"  height="12"/></TD>
<TD bordercolor="#330099" class="sidebarLink"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">my goal <A class="navi" href="people.html"></A></font></TD>
</TR>

<!-- Sibling  Links --><TR valign="top"><TD colspan="2" class="sidebarLink"><UL class="sidebarList">
<LI><B><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Meisam </font></B><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong> Hejazinia </strong></font></LI>
</UL></TD></TR></TABLE>
<br>
  <A href="/sitemap.html">View Site Map</A>
<br><br>



   <!-- Feedback Link BEGIN -->
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
<tr><td width="100%" bgcolor="#990000"></td></tr>
<tr><td><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
</table>
<b>Contact Us</b>
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
<tr><td width="100%" bgcolor="#990000"><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
<tr><td><img src="/images/common/empty.gif" width="150" height="1"></td></tr>
</table>

<font size="1">
    <DIV id="feedback"><A class="feedback" title="Share your comments or questions about this page with us" href="/cgi/feedback.pl"><IMG src="/images/common/feedback.gif" BORDER="0" width="14" height="11" alt="Share your comments or questions about this page with us"> Comments/Questions about this page?</A></DIV>
</font></font>
<p><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><font size="1"><br/>
  Amirkabir University of Technology </font></font><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
  
        <br/>
        <br/>
  </font></p>
<font size="2" face="Verdana, Arial, Helvetica, sans-serif">
<table wwidth="146" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="45"><a href="http://ce.aut.ac.ir"></a></td>
     </tr>
</table>
<!-- Feedback Link END   -->

</font></td>
</tr></table></td></tr>

</table></td>

</tr>
<tr></tr>
</table>

<!-- END MAIN BODY TABLE --></td>

  </tr>
  <tr> 
    <td colspan="2"> 
      <table width="750" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td>
            <table width="750" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="154">&nbsp;</td>
                <td>
                  <table width="596" border="0" cellspacing="0" cellpadding="0">
                    <tr> 
                      <td width="69%" align="right"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#000000">link 
                        1</font><font color="#003399"> - <a href="index2.htm">link 
                        2</a> - <a href="index3.htm">link 3</a> - <a href="index4.htm">link 
                        4</a> - <a href="index5.htm">link 5</a> - <a href="index6.htm">link 
                        6</a></font></b></font></td>
                      <td>&nbsp;</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      
    </td>
  </tr>
</table>
</body>
</html>
  
<script language="JavaScript">
// this code is taken from below man's website
//Analog clock script- By Amir Ali M (fbiaam@yahoo.com)
//Script featured on Dynamic Drive
//Visit http://www.sevom.persianblog.com for this script and more

fCol='444444'; //face colour.
sCol='FF0000'; //seconds colour.
mCol='444444'; //minutes colour.
hCol='444444'; //hours colour.

Ybase=30; //Clock height.
Xbase=30; //Clock width.


H='...';
H=H.split('');
M='....';
M=M.split('');
S='.....';
S=S.split('');
NS4=(document.layers);
NS6=(document.getElementById&&!document.all);
IE4=(document.all);
Ypos=0;
Xpos=0;
dots=12;
Split=360/dots;
if (NS6){
for (i=1; i < dots+1; i++){
document.write('<div id="n6Digits'+i+'" style="position:absolute;top:0px;left:0px;width:30px;height:30px;font-family:Arial;font-size:10px;color:#'+fCol+';text-align:center;padding-top:10px">'+i+'</div>');
}
for (i=0; i < M.length; i++){
document.write('<div id="Ny'+i+'" style="position:absolute;top:0px;left:0px;width:2px;height:2px;font-size:2px;background:#'+mCol+'"></div>');
}
for (i=0; i < H.length; i++){
document.write('<div id="Nz'+i+'" style="position:absolute;top:0px;left:0px;width:2px;height:2px;font-size:2px;background:#'+hCol+'"></div>');
}
for (i=0; i < S.length; i++){
document.write('<div id="Nx'+i+'" style="position:absolute;top:0px;left:0px;width:2px;height:2px;font-size:2px;background:#'+sCol+'"></div>');
}
}
if (NS4){
dgts='1 2 3 4 5 6 7 8 9 10 11 12';
dgts=dgts.split(' ')
for (i=0; i < dots; i++){
document.write('<layer name=nsDigits'+i+' top=0 left=0 height=30 width=30><center><font face=Arial size=1 color='+fCol+'>'+dgts[i]+'</font></center></layer>');
}
for (i=0; i < M.length; i++){
document.write('<layer name=ny'+i+' top=0 left=0 bgcolor='+mCol+' clip="0,0,2,2"></layer>');
}
for (i=0; i < H.length; i++){
document.write('<layer name=nz'+i+' top=0 left=0 bgcolor='+hCol+' clip="0,0,2,2"></layer>');
}
for (i=0; i < S.length; i++){
document.write('<layer name=nx'+i+' top=0 left=0 bgcolor='+sCol+' clip="0,0,2,2"></layer>');
}
}
if (IE4){
document.write('<div style="position:absolute;top:0px;left:0px"><div style="position:relative">');
for (i=1; i < dots+1; i++){
document.write('<div id="ieDigits" style="position:absolute;top:0px;left:0px;width:30px;height:30px;font-family:Arial;font-size:10px;color:'+fCol+';text-align:center;padding-top:10px">'+i+'</div>');
}
document.write('</div></div>')
document.write('<div style="position:absolute;top:0px;left:0px"><div style="position:relative">');
for (i=0; i < M.length; i++){
document.write('<div id=y style="position:absolute;width:2px;height:2px;font-size:2px;background:'+mCol+'"></div>');
}
document.write('</div></div>')
document.write('<div style="position:absolute;top:0px;left:0px"><div style="position:relative">');
for (i=0; i < H.length; i++){
document.write('<div id=z style="position:absolute;width:2px;height:2px;font-size:2px;background:'+hCol+'"></div>');
}
document.write('</div></div>')
document.write('<div style="position:absolute;top:0px;left:0px"><div style="position:relative">');
for (i=0; i < S.length; i++){
document.write('<div id=x style="position:absolute;width:2px;height:2px;font-size:2px;background:'+sCol+'"></div>');
}
document.write('</div></div>')
}



function clock(){
time = new Date ();
secs = time.getSeconds();
sec = -1.57 + Math.PI * secs/30;
mins = time.getMinutes();
min = -1.57 + Math.PI * mins/30;
hr = time.getHours();
hrs = -1.57 + Math.PI * hr/6 + Math.PI*parseInt(time.getMinutes())/360;

if (NS6){
Ypos=window.pageYOffset+window.innerHeight-Ybase-25;
Xpos=window.pageXOffset+window.innerWidth-Xbase-30;
for (i=1; i < dots+1; i++){
 document.getElementById("n6Digits"+i).style.top=Ypos-15+Ybase*Math.sin(-1.56 +i *Split*Math.PI/180)
 document.getElementById("n6Digits"+i).style.left=Xpos-15+Xbase*Math.cos(-1.56 +i*Split*Math.PI/180)
 }
for (i=0; i < S.length; i++){
 document.getElementById("Nx"+i).style.top=Ypos+i*Ybase/4.1*Math.sin(sec);
 document.getElementById("Nx"+i).style.left=Xpos+i*Xbase/4.1*Math.cos(sec);
 }
for (i=0; i < M.length; i++){
 document.getElementById("Ny"+i).style.top=Ypos+i*Ybase/4.1*Math.sin(min);
 document.getElementById("Ny"+i).style.left=Xpos+i*Xbase/4.1*Math.cos(min);
 }
for (i=0; i < H.length; i++){
 document.getElementById("Nz"+i).style.top=Ypos+i*Ybase/4.1*Math.sin(hrs);
 document.getElementById("Nz"+i).style.left=Xpos+i*Xbase/4.1*Math.cos(hrs);
 }
}
if (NS4){
Ypos=window.pageYOffset+window.innerHeight-Ybase-20;
Xpos=window.pageXOffset+window.innerWidth-Xbase-30;
for (i=0; i < dots; ++i){
 document.layers["nsDigits"+i].top=Ypos-5+Ybase*Math.sin(-1.045 +i*Split*Math.PI/180)
 document.layers["nsDigits"+i].left=Xpos-15+Xbase*Math.cos(-1.045 +i*Split*Math.PI/180)
 }
for (i=0; i < S.length; i++){
 document.layers["nx"+i].top=Ypos+i*Ybase/4.1*Math.sin(sec);
 document.layers["nx"+i].left=Xpos+i*Xbase/4.1*Math.cos(sec);
 }
for (i=0; i < M.length; i++){
 document.layers["ny"+i].top=Ypos+i*Ybase/4.1*Math.sin(min);
 document.layers["ny"+i].left=Xpos+i*Xbase/4.1*Math.cos(min);
 }
for (i=0; i < H.length; i++){
 document.layers["nz"+i].top=Ypos+i*Ybase/4.1*Math.sin(hrs);
 document.layers["nz"+i].left=Xpos+i*Xbase/4.1*Math.cos(hrs);
 }
}

if (IE4){
Ypos=document.body.scrollTop+window.document.body.clientHeight-Ybase-20;
Xpos=document.body.scrollLeft+window.document.body.clientWidth-Xbase-20;
for (i=0; i < dots; ++i){
 ieDigits[i].style.pixelTop=Ypos-15+Ybase*Math.sin(-1.045 +i *Split*Math.PI/180)
 ieDigits[i].style.pixelLeft=Xpos-15+Xbase*Math.cos(-1.045 +i *Split*Math.PI/180)
 }
for (i=0; i < S.length; i++){
 x[i].style.pixelTop =Ypos+i*Ybase/4.1*Math.sin(sec);
 x[i].style.pixelLeft=Xpos+i*Xbase/4.1*Math.cos(sec);
 }
for (i=0; i < M.length; i++){
 y[i].style.pixelTop =Ypos+i*Ybase/4.1*Math.sin(min);
 y[i].style.pixelLeft=Xpos+i*Xbase/4.1*Math.cos(min);
 }
for (i=0; i < H.length; i++){
 z[i].style.pixelTop =Ypos+i*Ybase/4.1*Math.sin(hrs);
 z[i].style.pixelLeft=Xpos+i*Xbase/4.1*Math.cos(hrs);
 }
}
setTimeout('clock()',100);
}
clock();
//-->
</script>
<script language="JavaScript">
