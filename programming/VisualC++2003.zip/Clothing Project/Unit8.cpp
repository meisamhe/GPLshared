//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit8.h"
#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TchangeForm *changeForm;
//---------------------------------------------------------------------------
__fastcall TchangeForm::TchangeForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TchangeForm::backBtnClick(TObject *Sender)
{
        anbarForm->Show();
        changeForm->Hide();
}
//---------------------------------------------------------------------------
