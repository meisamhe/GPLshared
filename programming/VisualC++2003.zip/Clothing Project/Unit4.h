//---------------------------------------------------------------------------

#ifndef Unit4H
#define Unit4H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TsellForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TButton *backBtn;
        void __fastcall backBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TsellForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TsellForm *sellForm;
//---------------------------------------------------------------------------
#endif
