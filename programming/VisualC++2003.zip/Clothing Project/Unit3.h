//---------------------------------------------------------------------------

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TstoreForm : public TForm
{
__published:	// IDE-managed Components
        TButton *sellBtn;
        TButton *configBtn;
        TButton *reportBtn;
        TLabel *Label1;
        TButton *backBtn;
        void __fastcall configBtnClick(TObject *Sender);
        void __fastcall reportBtnClick(TObject *Sender);
        void __fastcall backBtnClick(TObject *Sender);
        void __fastcall sellBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TstoreForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TstoreForm *storeForm;
//---------------------------------------------------------------------------
#endif
