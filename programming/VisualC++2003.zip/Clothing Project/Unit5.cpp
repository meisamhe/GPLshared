//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit5.h"
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TconfigForm *configForm;
//---------------------------------------------------------------------------
__fastcall TconfigForm::TconfigForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TconfigForm::backBtnClick(TObject *Sender)
{
        storeForm->Show();
        configForm->Hide();
}
//---------------------------------------------------------------------------
