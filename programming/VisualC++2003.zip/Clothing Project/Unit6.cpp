//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit6.h"
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TstoreReportForm *storeReportForm;
//---------------------------------------------------------------------------
__fastcall TstoreReportForm::TstoreReportForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TstoreReportForm::backBtnClick(TObject *Sender)
{
        storeForm->Show();
        storeReportForm->Hide();
}
//---------------------------------------------------------------------------
 