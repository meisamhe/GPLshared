//---------------------------------------------------------------------------

#ifndef Unit7H
#define Unit7H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TaddForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *label1;
        TButton *backBtn;
        TRadioGroup *seasonRadio;
        TRadioGroup *casualRadio;
        TComboBox *colorCombo;
        TEdit *colorEdit;
        TComboBox *kindCombo;
        TComboBox *sizeCombo;
        TComboBox *lengthCombo;
        TComboBox *coolwarmCombo;
        TComboBox *itemCombo00;
        TComboBox *tripCombo;
        TComboBox *tangiCombo;
        TEdit *codeEdit;
        TComboBox *itemCombo02;
        TComboBox *itemCombo01;
        TComboBox *itemCombo10;
        TComboBox *itemCombo12;
        TComboBox *itemCombo11;
        TComboBox *zerafatCombo;
        TComboBox *pictureCombo;
        TButton *registerBtn;
        TLabel *quantityLabel;
        TLabel *buyLabel;
        TLabel *sellLabel;
        TLabel *discountLabel;
        TLabel *seasonDisLabel;
        TLabel *Label7;
        TGroupBox *GroupBox1;
        TMaskEdit *MaskEdit1;
        TMaskEdit *MaskEdit2;
        TMaskEdit *MaskEdit3;
        TMaskEdit *MaskEdit4;
        TMaskEdit *MaskEdit5;
        TMaskEdit *MaskEdit6;
        TImage *Image1;
        TLabel *Label2;
        void __fastcall backBtnClick(TObject *Sender);
        void __fastcall colorComboSelect(TObject *Sender);
        void __fastcall seasonRadioClick(TObject *Sender);
        void __fastcall casualRadioClick(TObject *Sender);
        void __fastcall registerBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TaddForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TaddForm *addForm;
//---------------------------------------------------------------------------
#endif
