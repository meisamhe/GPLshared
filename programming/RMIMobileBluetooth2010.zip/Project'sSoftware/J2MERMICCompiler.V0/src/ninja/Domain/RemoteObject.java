package ninja.Domain;

import databaseCore.Entity;

/**
 * Created by IntelliJ IDEA.
 * User: Engineer
 * Date: Aug 29, 2009
 * Time: 12:22:53 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RemoteObject  {
}
