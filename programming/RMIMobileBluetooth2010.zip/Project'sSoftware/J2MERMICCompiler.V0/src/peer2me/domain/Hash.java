package peer2me.domain;

/**
 * Created by IntelliJ IDEA.
 * User: Engineer
 * Date: Sep 5, 2009
 * Time: 3:50:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class Hash {
    public String key;
    public Object value;
    public Hash(String key, Object value){
        this.key=key;
        this.value=value;
    }
}
