using System;

namespace ConsoleApplication1
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class values
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			//
			int myInt=7;
			System.Console.WriteLine("Initialiazed,myInt:{0}",myInt);
			myInt=5;
			System.Console.WriteLine("Intialiazed,myInt:{0}",myInt);
			//
		}
	}
}
