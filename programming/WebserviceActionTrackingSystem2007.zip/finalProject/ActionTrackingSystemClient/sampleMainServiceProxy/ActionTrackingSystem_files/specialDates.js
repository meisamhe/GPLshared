﻿addSpecialDate(1, 1, "عید نوروز", true);
addSpecialDate(2, 1, "عید نوروز", true);
addSpecialDate(3, 1, "عید نوروز", true);
addSpecialDate(4, 1, "عید نوروز", true);
addSpecialDate(12, 1, "روز جمهوری اسلامی", true);

addSpecialDate(22, 11, "پیروزی انقلاب اسلامی ایران", true);
addSpecialDate(29, 12, "روز ملی شدن صنعت نفت", true);
