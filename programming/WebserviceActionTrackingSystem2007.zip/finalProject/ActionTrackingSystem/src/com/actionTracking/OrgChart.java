package com.actionTracking;

public class OrgChart {
	
	OrgChart[] oc;
	String[] depts;
	
	public OrgChart(){
		
	}

}
