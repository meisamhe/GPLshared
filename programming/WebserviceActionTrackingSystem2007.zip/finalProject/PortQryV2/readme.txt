Please see the following Knowledge Base article for information on Portqry version 2.0:

832919 Portqry 2.0 New Features and Functionality
http://support.microsoft.com/?id=832919

