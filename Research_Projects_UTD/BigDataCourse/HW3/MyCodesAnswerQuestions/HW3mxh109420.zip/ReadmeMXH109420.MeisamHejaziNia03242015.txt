#===================================================================================
Submission: Homework 3 for Big Data class of Dr. Latifur Khan
Meisam Hejazi Nia 
Doctoral Candidate in Management Science (Marketing Analytics)
Naveen Jindal School of Management, The University of Texas at Dallas
800 W Campbell rd | School of Management |Richardson, TX, 75080
Cell: 469.999.2798 
Email: meisam.hejazinia@utdallas.edu 
View my complete profile: http://www.hejazinia.com/
#===================================================================================
The Zip file contains:
(1) BigDataHW3.txt: the file that shows increment, and where I have executed each of the queries
(2) Q1.pig-Q9.hive: 9 files containing the solution to each of the problems separateley, I have executed them on the interactive mode, but they can be executed in Batch mode as well by calling "pig -x mapreduce Qi.pig", where i=1-4, and "hive -f Qj.hive", where j=5-9. I ran pig codes on CS6360, and Hive on my own HortonWorks Virtual box, because it seems the server had problem in terms of configuraiton of Hive.
(3) FORMAT_GENRE_PIG.java, the reformating UDF for Q4. The command on how I have compiled it on CS6360, and the commands are available in BigDataHW3.txt
(4) FORMAT_GENRE_HIVE.java, the reformating UDF for Q4. The command on how I have compiled it on CS6360, and the commands are available in BigDataHW3.txt. It seems my HortonWorks does not have hadoop-core.*.jar, so I could not complie it on my HortonWork, so I used CS6360
(5) Q1-Q9.res, 9 files that show the result of execution of queries, for the one that had empty result (i.e. Q1), I put explanation of why it is empty that I find out by checking the subquery portion, the relaxed condition version
// If you had any problem in executing the code please do not hesitate to let me know

#===================================================================================
# End of File
Meisam Hejazi Nia 
Doctoral Candidate in Management Science (Marketing Analytics)
Naveen Jindal School of Management, The University of Texas at Dallas
800 W Campbell rd | School of Management |Richardson, TX, 75080
Cell: 469.999.2798 
Email: meisam.hejazinia@utdallas.edu 
View my complete profile: http://www.hejazinia.com/
#===================================================================================