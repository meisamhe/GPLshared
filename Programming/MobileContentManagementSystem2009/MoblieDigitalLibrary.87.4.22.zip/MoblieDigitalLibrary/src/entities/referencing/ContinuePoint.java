/**
 *                                      In the name of Allah
 *                                       The best will come
 */


package entities.referencing;

public class ContinuePoint {
    private Reference reference;

    public Reference getReference() {
        return reference;
    }

    public void setReference(Reference reference) {
        this.reference = reference;
    }
}