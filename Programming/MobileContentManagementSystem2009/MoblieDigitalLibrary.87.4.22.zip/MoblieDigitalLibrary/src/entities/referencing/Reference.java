/**
 *                                      In the name of Allah
 *                                       The best will come
 */


package entities.referencing;

public class Reference {
}