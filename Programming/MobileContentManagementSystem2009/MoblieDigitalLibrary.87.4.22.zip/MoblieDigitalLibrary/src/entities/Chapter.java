/**
 *                                      In the name of Allah
 *                                       The best will come
 */

package entities;

public abstract class Chapter {

    protected String title;

    public Chapter() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}