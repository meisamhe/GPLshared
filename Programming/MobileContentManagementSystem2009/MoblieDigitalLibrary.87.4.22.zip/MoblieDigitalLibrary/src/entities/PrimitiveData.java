/**
 *                                      In the name of Allah
 *                                       The best will come
 */

package entities;

public abstract class PrimitiveData {

    public PrimitiveData() {
    }
}
