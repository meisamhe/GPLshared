/**
 *                                      In the name of Allah
 *                                       The best will come
 */

package entities;

import java.util.Vector;

public class ASynchChapter extends Chapter {

    private Vector primitiveDatas;

    public ASynchChapter() {
    }

    public Vector getPrimitiveDatas() {
        return primitiveDatas;
    }

    public void setPrimitiveDatas(Vector primitiveDatas) {
        this.primitiveDatas = primitiveDatas;
    }
}
