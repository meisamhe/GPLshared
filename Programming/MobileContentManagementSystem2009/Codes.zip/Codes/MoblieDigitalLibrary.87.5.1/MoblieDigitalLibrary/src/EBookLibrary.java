import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

/**
 *                                      In the name of Allah
 *                                       The best will come
 */


public class EBookLibrary extends Canvas {
    protected void paint(Graphics graphics) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}