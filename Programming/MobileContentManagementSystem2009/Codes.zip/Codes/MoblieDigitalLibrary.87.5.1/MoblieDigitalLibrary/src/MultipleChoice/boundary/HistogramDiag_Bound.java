package MultipleChoice.boundary;

/**
 * @model.uin <code>design:node:::-tdsqjufgl3g3ehjap0zn</code>
 */
public class HistogramDiag_Bound extends statisticalView_Boundary {
}
