package MultipleChoice.boundary;

import MultipleChoice.control.Interactive_Control;

/**
 * @model.uin <code>design:node:::-tdsqjufaovtfut-jghthx</code>
 */
public class Timer_Boundary {



	/**
	 * @model.uin <code>design:node:::-tdsqjuffzu7tht-babwzh</code>
	 */
	public Interactive_Control interactive_Control;

	/**
	 * @model.uin <code>design:node:::hnimszfgkoeqgh-g08yts:-tdsqjufaovtfut-jghthx</code>
	 */
	String currentTimerType;

	/**
	 * @model.uin <code>design:node:::hnimszfgkqzk65vngi65:-tdsqjufaovtfut-jghthx</code>
	 */
	int value;

	/**
	 * @model.uin <code>design:node:::tq87glfaox7dkb6frkjv:-tdsqjufaovtfut-jghthx</code>
	 */
	void start() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfaox7kq6cfwbxl:-tdsqjufaovtfut-jghthx</code>
	 */
	void stop() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgko8i4j-ouja1m:-tdsqjufaovtfut-jghthx</code>
	 */
	void resume() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgko8wvs-lx4pkp:-tdsqjufaovtfut-jghthx</code>
	 */
	void pause() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgktfn5i-f625m0:-tdsqjufaovtfut-jghthx</code>
	 */
	void setValue() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgktfyj8-mlmff6:-tdsqjufaovtfut-jghthx</code>
	 */
	void getValue() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgktgs1q-bui6ou:-tdsqjufaovtfut-jghthx</code>
	 */
	void setCurrentTimeType() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgkth1pebvswi3:-tdsqjufaovtfut-jghthx</code>
	 */
	void getCurrentTimeType() {
		/* default generated stub */;

	}
}
