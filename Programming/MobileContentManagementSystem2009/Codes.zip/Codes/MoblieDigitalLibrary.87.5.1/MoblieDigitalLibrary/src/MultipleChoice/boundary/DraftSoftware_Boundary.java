package MultipleChoice.boundary;

import MultipleChoice.control.Interactive_Control;

/**
 * @model.uin <code>design:node:::-tdsqjufaowlpps-zco87p</code>
 */
public class DraftSoftware_Boundary {


	/**
	 * @model.uin <code>design:node:::-tdsqjuffzu7tht-babwzh</code>
	 */
	public Interactive_Control interactive_Control;

	/**
	 * @model.uin <code>design:node:::tq87glfarq247e-m2vi95:-tdsqjufaowlpps-zco87p</code>
	 */
	void $new$() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarq2hio-3e4284:-tdsqjufaowlpps-zco87p</code>
	 */
	void save() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarq2myjruf0rk:-tdsqjufaowlpps-zco87p</code>
	 */
	void load() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarqohecugtxlk:-tdsqjufaowlpps-zco87p</code>
	 */
	void open() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarqooxa-r4i44m:-tdsqjufaowlpps-zco87p</code>
	 */
	void close() {
		/* default generated stub */;

	}
}
