package MultipleChoice.boundary;

import MultipleChoice.control.Interactive_Control;

/**
 * @model.uin <code>design:node:::-tdsqjufgl1bx1n-i5hwcl</code>
 */
public class StaticInfoViewer_Boundary {

	/**
	 * @model.uin <code>design:node:::-tdsqjuffzu7tht-babwzh</code>
	 */
	public Interactive_Control interactive_Control;

	/**
	 * @model.uin <code>design:node:::hnimszfgl36i9k-qodcsz:-tdsqjufgl1bx1n-i5hwcl</code>
	 */
	java.lang.Object currentDisplay;

	/**
	 * @model.uin <code>design:node:::hnimszfgl376exql524s:-tdsqjufgl1bx1n-i5hwcl</code>
	 */
	java.lang.Object cacheDisplayList;

	/**
	 * @model.uin <code>design:node:::hnimszfgl37mzqaoul3m:-tdsqjufgl1bx1n-i5hwcl</code>
	 */
	java.lang.Object menueList;

	/**
	 * @model.uin <code>design:node:::tq87glfgl38w60t1fmg1:-tdsqjufgl1bx1n-i5hwcl</code>
	 */
	void setterGetterAttribute() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgl39rqbieqkel:-tdsqjufgl1bx1n-i5hwcl</code>
	 */
	void Draw() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgl3at84-2qf4sl:-tdsqjufgl1bx1n-i5hwcl</code>
	 */
	void fillBitMap() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgl3xygn-khb4z4:-tdsqjufgl1bx1n-i5hwcl</code>
	 */
	void eventHandler() {
		/* default generated stub */;

	}
}
