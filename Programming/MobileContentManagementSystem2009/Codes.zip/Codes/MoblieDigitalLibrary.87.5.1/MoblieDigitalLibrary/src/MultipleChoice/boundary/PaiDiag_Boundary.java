package MultipleChoice.boundary;

import MultipleChoice.boundary.statisticalView_Boundary;

/**
 * @model.uin <code>design:node:::-tdsqjufgl3ex3x-u4bapq</code>
 */
public class PaiDiag_Boundary extends statisticalView_Boundary {
}
