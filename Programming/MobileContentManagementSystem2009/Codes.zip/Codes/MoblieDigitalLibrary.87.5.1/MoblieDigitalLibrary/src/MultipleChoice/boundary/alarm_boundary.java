package MultipleChoice.boundary;

import MultipleChoice.control.Interactive_Control;

/**
 * @model.uin <code>design:node:::-tdsqjufaova9c0-kstaiw</code>
 */
public class alarm_boundary {



	/**
	 * @model.uin <code>design:node:::-tdsqjuffzu7tht-babwzh</code>
	 */
	public Interactive_Control interactive_Control;

	/**
	 * @model.uin <code>design:node:::hba2kfgktk7pkzewycz:-tdsqjufaova9c0-kstaiw</code>
	 */
	String path;

	/**
	 * @model.uin <code>design:node:::ie00tfgktldhh-evpx7f:-tdsqjufaova9c0-kstaiw</code>
	 */
	String Type;

	/**
	 * @model.uin <code>design:node:::tq87glfarq505ziv9t7a:-tdsqjufaova9c0-kstaiw</code>
	 */
	void alarm() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::i4qbafgktlnvl31w59m:-tdsqjufaova9c0-kstaiw</code>
	 */
	void getFileType() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::irhjufgktlnvl5oxnws:-tdsqjufaova9c0-kstaiw</code>
	 */
	void setFileType() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::3ifb3fgktmsaw-gi99jk:-tdsqjufaova9c0-kstaiw</code>
	 */
	void getPath() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::dxsydfgktl3ijht6uck:-tdsqjufaova9c0-kstaiw</code>
	 */
	void setpath() {
		/* default generated stub */;

	}
}
