package MultipleChoice.boundary;

import MultipleChoice.control.Interactive_Control;

/**
 * @model.uin <code>design:node:::-tdsqjufgl1av2w-h6mnv9</code>
 */
public class userFormsView_Boundary {

	/**
	 * @model.uin <code>design:node:::-tdsqjuffzu7tht-babwzh</code>
	 */
	public Interactive_Control interactive_Control;

	/**
	 * @model.uin <code>design:node:::hnimszfgl3o3mc8sfzvn:-tdsqjufgl1av2w-h6mnv9</code>
	 */
	java.lang.Object menueList;

	/**
	 * @model.uin <code>design:node:::tq87glfgl3plsg-3ds8y0:-tdsqjufgl1av2w-h6mnv9</code>
	 */
	void draw() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgl3uucn3f8pa2:-tdsqjufgl1av2w-h6mnv9</code>
	 */
	void setterGetterAttribute() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgl3wzd7yyxagm:-tdsqjufgl1av2w-h6mnv9</code>
	 */
	void eventHandler() {
		/* default generated stub */;

	}
}
