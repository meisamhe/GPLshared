/**
 *                                      In the name of Allah
 *                                       The best will come
 */

package entities;

public class ComplexPrimitiveData extends PrimitiveData {

    public ComplexPrimitiveData() {
    }
}
