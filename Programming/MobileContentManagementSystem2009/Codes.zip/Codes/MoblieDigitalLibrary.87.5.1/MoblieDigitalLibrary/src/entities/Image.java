/**
 *                                      In the name of Allah
 *                                       The best will come
 */

package entities;

public class Image extends ComplexPrimitiveData {

    private String path;

    public Image() {
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
