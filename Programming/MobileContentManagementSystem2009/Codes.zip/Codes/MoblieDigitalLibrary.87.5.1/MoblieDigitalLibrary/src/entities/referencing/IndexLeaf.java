/**
 *                                      In the name of Allah
 *                                       The best will come
 */


package entities.referencing;

public class IndexLeaf extends IndexRoot {
    public IndexLeaf(String title, Reference reference) {
        super(title, reference);
    }
}