package org.garret.perst;

/**
 * Interface of persistent set. 
 */
public interface IPersistentSet extends IPersistent, IResource, Set {}
