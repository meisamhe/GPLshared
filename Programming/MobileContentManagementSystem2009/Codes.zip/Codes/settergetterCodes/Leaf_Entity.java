/**
 * checked
 */
 
package testEntities;

public class Leaf_Entity extends Hierarchy_Entity {

	protected long testRefereence;

    public void changeNodePlace() {
	
	}

    public void setTestRefereence(long testRefereence){
        this.testRefereence=testRefereence;
    }
    public long getTestRefereence(){
        return testRefereence;
   }   
}
