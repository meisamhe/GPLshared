package databaseTest.Guess;

interface NewNodeCallback {
    void callback(TreeNode node);
}