package databaseTest.Guess;

interface Answer {
    void answer(boolean yes);
}