package MultipleChoice.boundary;

/**
 * @model.uin <code>design:node:::-tdsqjufarq68yl-u654ip</code>
 */
public class alarm2Adaptor_boundary extends alarm_boundary {

	/**
	 * @model.uin <code>design:node:::tq87glfarqddjhp94lvi:-tdsqjufarq68yl-u654ip</code>
	 */
	void show() {
		/* default generated stub */;

	}
}
