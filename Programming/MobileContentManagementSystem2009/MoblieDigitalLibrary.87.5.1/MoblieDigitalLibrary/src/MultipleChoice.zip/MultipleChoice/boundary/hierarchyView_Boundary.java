package MultipleChoice.boundary;

/**
 * @model.uin <code>design:node:::-tdsqjufgl0z5a0q90bi3</code>
 */
public class hierarchyView_Boundary {

	/**
	 * @model.uin <code>design:node:::-tdsqjuffzu7tht-babwzh</code>
	 */
	public interactive_Control interactive_Control;

	/**
	 * @model.uin <code>design:node:::hnimszfgl3nayo-fyow44:-tdsqjufgl0z5a0q90bi3</code>
	 */
	java.lang.Object menueList;

	/**
	 * @model.uin <code>design:node:::tq87glfgl3jbdelow8ik:-tdsqjufgl0z5a0q90bi3</code>
	 */
	void draw() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgl3u4ol-rcgxrx:-tdsqjufgl0z5a0q90bi3</code>
	 */
	void setterGetterAttribute() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgl3wpjw-xs7vy8:-tdsqjufgl0z5a0q90bi3</code>
	 */
	void eventHandler() {
		/* default generated stub */;

	}
}
