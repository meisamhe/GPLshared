package MultipleChoice.boundary;

/**
 * A Classed used for using alarm that are like sound, this will perform as an adaptor
   *
   * @author  Mr.Hejazinia & Ms.Delpishe
   * @version %1%, %0%
 */
public class alarm1Adaptor_boundary extends alarm_boundary {

	/**
	 * will play a sound in a thread
	 */
	void play() {
		/* default generated stub */;

	}
}
