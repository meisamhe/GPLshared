package MultipleChoice.boundary;

/**
 * @model.uin <code>design:node:::-tdsqjufaowly8mia4m50</code>
 */
public class CalculatorSoftware_Boundary {

	/**
	 * @model.uin <code>design:node:::-tdsqjuffzu7tht-babwzh</code>
	 */
	public interactive_Control interactive_Control;

	/**
	 * @model.uin <code>design:node:::-tdsqjufaowdlhxi8zhzt</code>
	 */
	public view view;

	/**
	 * @model.uin <code>design:node:::e8fxbfarq8cgd-pw3zvq:-tdsqjufaowly8mia4m50</code>
	 */
	void logic() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarq388m-siavmy:-tdsqjufaowly8mia4m50</code>
	 */
	void arithmetic() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarq3ojl50m2lo:-tdsqjufaowly8mia4m50</code>
	 */
	void triangular() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarq3wse-kx8vlp:-tdsqjufaowly8mia4m50</code>
	 */
	void saveLoad() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarq4bl42bg64u:-tdsqjufaowly8mia4m50</code>
	 */
	void statistic() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarqp1k4-uza4pb:-tdsqjufaowly8mia4m50</code>
	 */
	void open() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfarqpak63ofv2z:-tdsqjufaowly8mia4m50</code>
	 */
	void close() {
		/* default generated stub */;

	}
}
