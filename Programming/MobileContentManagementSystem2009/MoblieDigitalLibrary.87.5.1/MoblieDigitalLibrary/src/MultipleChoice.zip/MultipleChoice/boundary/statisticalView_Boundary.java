package MultipleChoice.boundary;

/**
 * @model.uin <code>design:node:::-tdsqjufgl0zp8b-5hwssj</code>
 */
public class statisticalView_Boundary {

	/**
	 * @model.uin <code>design:node:::-tdsqjuffzu7tht-babwzh</code>
	 */
	public interactive_Control interactive_Control;

	/**
	 * @model.uin <code>design:node:::hnimszfgl3kvxfw1jvcf:-tdsqjufgl0zp8b-5hwssj</code>
	 */
	java.lang.Object menueList;

	/**
	 * @model.uin <code>design:node:::tq87glfgl3ehbsbxb54a:-tdsqjufgl0zp8b-5hwssj</code>
	 */
	void draw() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgl3k9mwyhwu8f:-tdsqjufgl0zp8b-5hwssj</code>
	 */
	void setterGetterAttribute() {
		/* default generated stub */;

	}

	/**
	 * @model.uin <code>design:node:::tq87glfgl3xf99-qml99u:-tdsqjufgl0zp8b-5hwssj</code>
	 */
	void eventHandler() {
		/* default generated stub */;

	}
}
