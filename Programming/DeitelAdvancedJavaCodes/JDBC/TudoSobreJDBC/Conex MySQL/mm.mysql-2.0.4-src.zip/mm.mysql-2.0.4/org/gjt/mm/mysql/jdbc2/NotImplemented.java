package org.gjt.mm.mysql.jdbc2;

public class NotImplemented extends java.sql.SQLException
{
}
